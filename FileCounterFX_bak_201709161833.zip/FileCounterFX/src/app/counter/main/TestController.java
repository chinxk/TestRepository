package app.counter.main;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class TestController extends Application implements Initializable {

	@FXML
	private TextField tfPath;
	@FXML
	private TextField tfHrs;
	@FXML
	private TextField tfMin;
	@FXML
	private Label l;
	@FXML
	private Button btnFileChooser;
	@FXML
	private DatePicker fileDatePicker;

	private static Stage primaryStage;

	private void setPrimaryStage(Stage stage) {
		TestController.primaryStage = stage;
	}

	static public Stage getPrimaryStage() {
		return primaryStage;
	}

	@FXML
	protected void handlePathButtonAction(ActionEvent event) {
		DirectoryChooser chooser = new DirectoryChooser();
		File chosenDir = chooser.showDialog(primaryStage);
		if (chosenDir != null) {
			System.out.println(chosenDir.getAbsolutePath());
			tfPath.setText(chosenDir.getAbsolutePath());
		} else {
			System.out.print("no directory chosen");
		}

		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			public void run() {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						String path = tfPath.getText();
						File f = new File(path);
						if (f.isDirectory() && f.list().length > 0) {

							FileFilter ff = new FileFilter() {

								@Override
								public boolean accept(File file) {
									long m = file.lastModified();
									DateFormat dfHrs = new SimpleDateFormat("HH");
									DateFormat dfMin = new SimpleDateFormat("mm");
									Calendar date = Calendar.getInstance();
									date.setTimeInMillis(m);
									Integer fileHrs = Integer.valueOf(dfHrs.format(date.getTime()));
									Integer fileMin = Integer.valueOf(dfMin.format(date.getTime()));
									Integer iptHrs = Integer.valueOf(tfHrs.getText());
									Integer iptMin = Integer.valueOf(tfMin.getText());
									file.exists();
									//TODO date
									return !file.isHidden()
											&& (fileHrs > iptHrs || fileHrs == iptHrs && fileMin >= iptMin);
								}
							};

							int cnt = f.listFiles(ff).length;
							System.out.println(cnt);
							l.setText(String.valueOf(cnt));
							f.exists();
						} else {
							System.out.println("not a directory");
						}
					}

				});
			}
		}, 1000, 1000);
	}

	@Override
	public void start(Stage stage) throws IOException {

		setPrimaryStage(stage);
		Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("GridFxml.fxml"));
		Scene scene = new Scene(root, 250, 450);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setTitle("FilesCounterFX");

		stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				System.exit(0);
			}
		});
		stage.show();

	}

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		DateFormat dfHrs = new SimpleDateFormat("HH");
		DateFormat dfMin = new SimpleDateFormat("mm");
		Calendar date = Calendar.getInstance();
		date.setTimeInMillis(System.currentTimeMillis());
		Integer nowHrs = Integer.valueOf(dfHrs.format(date.getTime()));
		Integer nowMin = Integer.valueOf(dfMin.format(date.getTime()));
		tfHrs.setText(String.valueOf(nowHrs));
		tfMin.setText(String.valueOf(nowMin));

		fileDatePicker.setValue(LocalDate.now());

		l.setFont(new Font("Arial", 60));  
		l.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				l.setScaleX(2.5);
				l.setScaleY(2.5);
			}
		});
		l.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				l.setScaleX(1);
				l.setScaleY(1);
			}
		});

	}

}
