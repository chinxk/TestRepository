package app.counter.main;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class TestController extends Application implements Initializable {

	@FXML
	private TextField tfPath;
	@FXML
	private TextField tfHrs;
	@FXML
	private TextField tfMin;
	@FXML
	private Label lblSum;
	@FXML
	private Button btnFileChooser;
	@FXML
	private DatePicker fileDatePicker;

	private static Stage primaryStage;

	private void setPrimaryStage(Stage stage) {
		TestController.primaryStage = stage;
	}

	static public Stage getPrimaryStage() {
		return primaryStage;
	}

	@FXML
	protected void handleOnTfHrsReleasedAction(KeyEvent event) {
		String t = tfHrs.getText();
		if (t.matches("\\d+") && Integer.valueOf(t) >= 0 && Integer.valueOf(t) <= 24) {

		} else {
			tfHrs.setText("0");
		}
	}

	@FXML
	protected void handleOnTfMinReleasedAction(KeyEvent event) {
		String t = tfMin.getText();
		if (t.matches("\\d+") && Integer.valueOf(t) >= 0 && Integer.valueOf(t) <= 59) {

		} else {
			tfMin.setText("0");
		}
	}

	@FXML
	protected void handleOnMouseEnteredAction(MouseEvent event) {
		lblSum.setScaleX(2.2);
		lblSum.setScaleY(2.2);
	}

	@FXML
	protected void handleOnMouseExitedAction(MouseEvent event) {
		lblSum.setScaleX(1.0);
		lblSum.setScaleY(1.0);
	}

	@FXML
	protected void handlePathButtonAction(ActionEvent event) {
		DirectoryChooser chooser = new DirectoryChooser();
		File chosenDir = chooser.showDialog(primaryStage);
		if (chosenDir != null) {
			System.out.println(chosenDir.getAbsolutePath());
			tfPath.setText(chosenDir.getAbsolutePath());
		} else {
			System.out.print("no directory chosen");
		}

		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			public void run() {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						String path = tfPath.getText();
						File f = new File(path);
						if (f.isDirectory() && f.list().length > 0) {

							FileFilter ff = new FileFilter() {

								@Override
								public boolean accept(File file) {

									// get file modified instant
									long m = file.lastModified();
									Calendar fileDate = Calendar.getInstance();
									fileDate.setTimeInMillis(m);
									Instant istFile = fileDate.toInstant();
									Integer iptHrs = Integer.valueOf(tfHrs.getText());
									Integer iptMin = Integer.valueOf(tfMin.getText());

									// get input instant
									LocalTime iptTime = LocalTime.of(iptHrs, iptMin);
									LocalDate iptDate = fileDatePicker.getValue();
									LocalDateTime iptLdt = iptDate.atTime(iptTime);
									Instant istInput = iptLdt.toInstant(ZoneOffset.ofHours(8));

									return !file.isHidden() && (istFile.compareTo(istInput) >= 0);
								}
							};

							int cnt = f.listFiles(ff).length;
							System.out.println(cnt);
							lblSum.setText(String.valueOf(cnt));
							if (cnt >= 180) {
								lblSum.getStyleClass().add("alert");
							}else {
								lblSum.getStyleClass().remove("alert");
							}
							f.exists();
						} else {
							System.out.println("not a directory");
						}
					}

				});
			}
		}, 1000, 1000);
	}

	@Override
	public void start(Stage stage) throws IOException {

		setPrimaryStage(stage);
		Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("GridFxml.fxml"));
		Scene scene = new Scene(root, 250, 450);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		stage.setScene(scene);
		stage.setTitle("FilesCounterFX");

		stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				System.exit(0);
			}
		});
		stage.show();

	}

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		LocalDateTime ldtNow = LocalDateTime.now();
		tfHrs.setText(String.valueOf(ldtNow.getHour()));
		tfMin.setText(String.valueOf(ldtNow.getMinute()));

		fileDatePicker.setValue(LocalDate.now());

	}

}
