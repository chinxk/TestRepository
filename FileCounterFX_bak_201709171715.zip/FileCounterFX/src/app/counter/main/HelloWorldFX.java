package app.counter.main;

import java.io.File;
import java.io.FileFilter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class HelloWorldFX extends Application {

	private TextField tfPath = new TextField();
	private TextField tfHrs = new TextField();
	private TextField tfMin = new TextField();
	private Label l = new Label();

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {

		initUI(primaryStage);

		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			public void run() {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						String path = tfPath.getText();
						File f = new File(path);
						if (f.isDirectory()) {

							FileFilter ff = new FileFilter() {

								@Override
								public boolean accept(File file) {
									long m = file.lastModified();
									DateFormat dfHrs = new SimpleDateFormat("HH");
									DateFormat dfMin = new SimpleDateFormat("mm");
									Calendar date = Calendar.getInstance();
									date.setTimeInMillis(m);
									Integer fileHrs = Integer.valueOf(dfHrs.format(date.getTime()));
									Integer fileMin = Integer.valueOf(dfMin.format(date.getTime()));
									Integer iptHrs = Integer.valueOf(tfHrs.getText());
									Integer iptMin = Integer.valueOf(tfMin.getText());
									file.exists();
									return !file.isHidden()
											&& (fileHrs > iptHrs || fileHrs == iptHrs && fileMin >= iptMin);
								}
							};

							int cnt = f.listFiles(ff).length;
							l.setText(String.valueOf(cnt));
							f.exists();
						} else {
							System.out.println("not a directory");
						}
					}

				});
			}
		}, 1000, 1000);

	}

	private void initUI(Stage primaryStage) {

		primaryStage.setTitle("FilesCounterFX");
		Button btnFileChooser = new Button();
		btnFileChooser.setText("...");
		DirectoryChooser chooser = new DirectoryChooser();
		btnFileChooser.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				File chosenDir = chooser.showDialog(primaryStage);
				if (chosenDir != null) {
					System.out.println(chosenDir.getAbsolutePath());
					tfPath.setText(chosenDir.getAbsolutePath());
				} else {
					System.out.print("no directory chosen");
				}
			}
		});

		Label lHrs = new Label();
		lHrs.setText("Hrs");
		lHrs.setMaxWidth(50);
		Label lMin = new Label();
		lMin.setText("Min");
		lMin.setMaxWidth(50);

		setCmbNow();

		GridPane gridPane = new GridPane();
		gridPane.setHgap(10);
		gridPane.setVgap(10);

		gridPane.add(tfHrs, 0, 1);
		gridPane.add(lHrs, 1, 1);
		gridPane.add(tfMin, 2, 1);
		gridPane.add(lMin, 3, 1);

		tfPath.setMaxWidth(100);
		gridPane.add(tfPath, 0, 2);
		gridPane.add(btnFileChooser, 3, 2);
		l.setFont(new Font("Cambria", 32));
		l.setTranslateY(50);
		gridPane.add(l, 0, 4);

		StackPane root = new StackPane();
		root.getChildren().add(gridPane);
		primaryStage.setScene(new Scene(root, 500, 400));
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				System.exit(0);
			}
		});
		primaryStage.show();
	}

	private void setCmbNow() {
		DateFormat dfHrs = new SimpleDateFormat("HH");
		DateFormat dfMin = new SimpleDateFormat("mm");
		Calendar date = Calendar.getInstance();
		date.setTimeInMillis(System.currentTimeMillis());
		Integer nowHrs = Integer.valueOf(dfHrs.format(date.getTime()));
		Integer nowMin = Integer.valueOf(dfMin.format(date.getTime()));
		tfHrs.setText(String.valueOf(nowHrs));
		tfMin.setText(String.valueOf(nowMin));
	}

	// private Integer[] generateIntArray(int i) {
	//
	// Integer[] r = new Integer[i];
	// for (; i > 0; i--) {
	// r[i - 1] = i - 1;
	// }
	// return r;
	// }
}
